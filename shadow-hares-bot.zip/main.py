import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

BOT_OWNER_ID = int(os.getenv("OWNER_ID"))

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("أهلاً بيك في بوت شادو الحارس!")

async def silence(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id == BOT_OWNER_ID:
        await update.message.reply_text("البوت سكت خلاص!")
    else:
        await update.message.reply_text("مش مسموحلك بالأمر ده.")

async def activate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id == BOT_OWNER_ID:
        await update.message.reply_text("البوت اشتغل تاني!")
    else:
        await update.message.reply_text("مش مسموحلك بالأمر ده.")

app = ApplicationBuilder().token(os.getenv("BOT_TOKEN")).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("اسكت", silence))
app.add_handler(CommandHandler("اشتغل", activate))

app.run_polling()
